package com.yy.lottierecoder;

/**
 * 渲染环境接口
 *
 * @author like
 * @date 2017-09-20
 */
public interface IGLEnvironment {

    /**
     * 请求渲染器渲染帧
     */
    void requestRender();
}