package com.yy.lottierecoder.encoders;

/**
 * @author ferrisXu
 * 创建日期：2019/3/28
 * 描述：
 */
public enum MaskType {
    mask,mask_photo,mask_bg
}
