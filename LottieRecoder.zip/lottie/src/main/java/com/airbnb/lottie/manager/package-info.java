@RestrictTo(LIBRARY)
package com.airbnb.lottie.manager;

import android.support.annotation.RestrictTo;

import static android.support.annotation.RestrictTo.Scope.LIBRARY;