package com.airbnb.lottie;

@Deprecated
public interface Cancellable {
  void cancel();
}
