package com.airbnb.lottie.animation.content;

import com.airbnb.lottie.model.KeyPathElement;

public interface KeyPathElementContent extends KeyPathElement, Content {
}
