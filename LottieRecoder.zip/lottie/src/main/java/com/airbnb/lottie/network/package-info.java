@RestrictTo(LIBRARY)
package com.airbnb.lottie.network;

import android.support.annotation.RestrictTo;

import static android.support.annotation.RestrictTo.Scope.LIBRARY;